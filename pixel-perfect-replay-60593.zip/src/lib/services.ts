import { Globe, ShoppingBag, LayoutDashboard, Rocket, RefreshCw, Server, Wrench, Workflow, type LucideIcon } from "lucide-react";

export type Service = { no: string; title: string; icon: LucideIcon; summary: string; items: string[] };

export const SERVICES: Service[] = [
  { no: "01", title: "Website Design & Development", icon: Globe, summary: "Professional websites designed to communicate your brand, services, and business identity.", items: ["Corporate websites", "Business websites", "Startup websites", "Portfolio websites", "Professional service websites", "Institutional websites"] },
  { no: "02", title: "E-Commerce Development", icon: ShoppingBag, summary: "Digital storefronts designed to help businesses showcase and sell products online.", items: ["Product catalogues", "Shopping cart", "Payment gateway integration", "Order management", "Customer enquiry systems", "Product management"] },
  { no: "03", title: "Custom Web Applications", icon: LayoutDashboard, summary: "Business-oriented web applications developed around specific operational requirements.", items: ["Business management applications", "Administrative dashboards", "Customer portals", "Registration systems", "Workflow applications", "Database-driven applications"] },
  { no: "04", title: "Landing Page Development", icon: Rocket, summary: "High-quality landing pages built to focus attention and drive action.", items: ["Marketing campaigns", "Product launches", "Lead generation", "Business promotions", "Event registrations"] },
  { no: "05", title: "Website Redesign & Modernization", icon: RefreshCw, summary: "Upgrade existing websites with modern layouts, improved navigation, responsive design, and better user experiences.", items: ["Modern layouts", "Improved navigation", "Responsive design", "Better user experience"] },
  { no: "06", title: "Domain, Hosting & Deployment", icon: Server, summary: "End-to-end assistance getting your website live and secure.", items: ["Domain configuration", "DNS management", "Hosting setup", "SSL configuration", "Website deployment", "Technical handover"] },
  { no: "07", title: "Website Maintenance & Support", icon: Wrench, summary: "Ongoing website support according to client requirements.", items: ["Content updates", "Bug fixes", "Performance improvements", "Technical troubleshooting", "Feature enhancements"] },
  { no: "08", title: "Digital Transformation & Automation", icon: Workflow, summary: "Business-focused technology solutions to simplify processes and improve digital operations.", items: ["Process digitisation", "Workflow simplification", "Operational tooling"] },
];
