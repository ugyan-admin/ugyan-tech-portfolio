import kodaiD from "@/assets/projects/kodai-charity-desktop.jpg.asset.json";
import kodaiM from "@/assets/projects/kodai-charity-mobile.jpg.asset.json";
import janD from "@/assets/projects/janapriya-internet-desktop.jpg.asset.json";
import janM from "@/assets/projects/janapriya-internet-mobile.jpg.asset.json";
import gkD from "@/assets/projects/gk-legal-firm-desktop.jpg.asset.json";
import gkM from "@/assets/projects/gk-legal-firm-mobile.jpg.asset.json";
import spD from "@/assets/projects/spektrum-gems-desktop.jpg.asset.json";
import spM from "@/assets/projects/spektrum-gems-mobile.jpg.asset.json";
import smD from "@/assets/projects/student-mitra-desktop.jpg.asset.json";
import smM from "@/assets/projects/student-mitra-mobile.jpg.asset.json";
import ngD from "@/assets/projects/ngg-plants-desktop.jpg.asset.json";
import ngM from "@/assets/projects/ngg-plants-mobile.jpg.asset.json";
import ppD from "@/assets/projects/palleturu-pachallu-desktop.jpg.asset.json";
import ppM from "@/assets/projects/palleturu-pachallu-mobile.jpg.asset.json";
import dlD from "@/assets/projects/dharma-legal-services-desktop.jpg.asset.json";
import dlM from "@/assets/projects/dharma-legal-services-mobile.jpg.asset.json";

export const CATEGORIES = [
  "All Projects",
  "Corporate & Business",
  "Legal & Professional",
  "Education",
  "E-Commerce & Products",
  "Horticulture",
  "Charity & Social Impact",
  "Local Services",
] as const;
export type Category = (typeof CATEGORIES)[number];

export type Project = {
  slug: string;
  no: string;
  name: string;
  url: string;
  industry: string;
  category: string;
  filters: Category[];
  short: string;
  description: string[];
  highlights: string[];
  contribution: string[];
  desktop: string;
  mobile: string;
};

const dd = ["Requirement understanding", "Website development", "Deployment to the live domain"];
const ddd = ["Requirement understanding", "Website design", "Website development", "Deployment to the live domain"];

export const PROJECTS: Project[] = [
  {
    slug: "kodai-charity", no: "01", name: "Kodai Charity", url: "https://kodaicharity.in/",
    industry: "Charity and Social Impact", category: "Charity Website Development",
    filters: ["Charity & Social Impact"],
    short: "A dedicated digital presence for a charitable organisation.",
    description: [
      "UGYAN TECH SOLUTIONS successfully developed and deployed the website for Kodai Charity, establishing a dedicated digital presence for the organization.",
      "The project represents our experience in creating digital platforms for charitable and social impact initiatives, with an emphasis on organizational identity, accessible information, and digital communication.",
    ],
    highlights: ["Charity-focused digital presence", "Organization introduction", "Structured information presentation", "Professional website deployment"],
    contribution: dd, desktop: kodaiD.url, mobile: kodaiM.url,
  },
  {
    slug: "janapriya-internet", no: "02", name: "Janapriya Internet", url: "https://janapriya.netlify.app/",
    industry: "Internet and Digital Services", category: "Local Business Website",
    filters: ["Local Services", "Corporate & Business"],
    short: "An online identity for a local internet and documentation services business.",
    description: [
      "Janapriya Internet provides internet access and digital documentation-related services.",
      "UGYAN TECH SOLUTIONS developed and deployed its website to establish an online identity and introduce its range of services to customers.",
      "The project demonstrates our ability to develop practical digital platforms for local service businesses.",
    ],
    highlights: ["Business introduction", "Digital service presentation", "Customer information accessibility", "Online business presence"],
    contribution: dd, desktop: janD.url, mobile: janM.url,
  },
  {
    slug: "gk-legal-firm", no: "03", name: "GK Legal Firm", url: "https://www.gklegalfirm.com/",
    industry: "Legal and Professional Services", category: "Professional Legal Website",
    filters: ["Legal & Professional", "Corporate & Business"],
    short: "A professional digital identity for a legal services organisation.",
    description: [
      "UGYAN TECH SOLUTIONS successfully designed, developed, and deployed the website for GK Legal Firm.",
      "The website establishes a professional digital identity for the legal services organization and provides a platform to communicate its professional presence and services.",
      "This project demonstrates our experience in developing websites for professional service organizations.",
    ],
    highlights: ["Professional legal business identity", "Structured service presentation", "Professional website design", "Digital presence development"],
    contribution: ddd, desktop: gkD.url, mobile: gkM.url,
  },
  {
    slug: "spektrum-gems", no: "04", name: "Spektrum Gems", url: "https://spektrumgems.com/",
    industry: "Gemstones and Precious Stones", category: "Specialty Product Business Website",
    filters: ["E-Commerce & Products", "Corporate & Business"],
    short: "A brand-focused digital identity for a specialised gemstone business.",
    description: [
      "UGYAN TECH SOLUTIONS developed and deployed the official website for Spektrum Gems.",
      "The project focuses on creating a digital identity for a specialized gemstone business through professional presentation, structured content, and a digital platform aligned with the brand's industry.",
    ],
    highlights: ["Gemstone industry digital presence", "Brand-focused presentation", "Product-oriented website structure", "Professional web development"],
    contribution: dd, desktop: spD.url, mobile: spM.url,
  },
  {
    slug: "student-mitra", no: "05", name: "Student Mitra", url: "https://www.studentsmitra.com/",
    industry: "Education and Student Services", category: "Education-Focused Digital Platform",
    filters: ["Education"],
    short: "A modern, accessible online experience built for students.",
    description: [
      "UGYAN TECH SOLUTIONS successfully developed and delivered the Student Mitra website, an education-focused digital platform designed to provide students with a modern, accessible, and engaging online experience.",
      "The project demonstrates our capabilities in developing student-oriented digital experiences with an emphasis on usability, responsive design, and structured content.",
    ],
    highlights: ["Student-focused digital experience", "Responsive website design", "Modern user interface", "Structured content presentation", "Scalable development approach"],
    contribution: dd, desktop: smD.url, mobile: smM.url,
  },
  {
    slug: "ngg-plants", no: "06", name: "NGG Plants", url: "https://www.nggplants.com/",
    industry: "Horticulture and Plant Nursery", category: "Nursery and Horticulture Website",
    filters: ["Horticulture"],
    short: "A dedicated digital platform for a plant nursery and horticulture business.",
    description: [
      "UGYAN TECH SOLUTIONS developed and deployed the website for NGG Plants, creating a dedicated digital platform for its plant nursery and horticulture business.",
      "The project represents our experience in supporting businesses within the plant, nursery, and landscaping ecosystem through professional digital solutions.",
    ],
    highlights: ["Nursery business digital presence", "Horticulture-focused presentation", "Plant and product showcase", "Online business identity"],
    contribution: dd, desktop: ngD.url, mobile: ngM.url,
  },
  {
    slug: "palleturu-pachallu", no: "07", name: "Palleturu Pachallu", url: "https://palleturupachallu.com/",
    industry: "Traditional Food Products", category: "Food Brand and Product Showcase Website",
    filters: ["E-Commerce & Products"],
    short: "A traditional Andhra food brand with WhatsApp-based product enquiries.",
    description: [
      "UGYAN TECH SOLUTIONS successfully designed, developed, and deployed the official website for Palleturu Pachallu, a traditional Andhra food brand.",
      "The website showcases traditional food products through organized categories and a customer-friendly digital experience.",
      "The project incorporates WhatsApp-based customer enquiry functionality, helping prospective customers connect directly with the business regarding products and orders.",
    ],
    highlights: ["Product category presentation", "Traditional food brand storytelling", "Product showcase", "WhatsApp-based enquiry functionality", "Customer communication experience"],
    contribution: [...ddd.slice(0, 3), "WhatsApp enquiry integration", "Deployment to the live domain"], desktop: ppD.url, mobile: ppM.url,
  },
  {
    slug: "dharma-legal-services", no: "08", name: "Dharma Legal Services", url: "https://dharmalegals.in/",
    industry: "Legal and Professional Services", category: "Legal Services Website Development",
    filters: ["Legal & Professional", "Corporate & Business"],
    short: "A professional platform presenting legal services and clear contact channels.",
    description: [
      "UGYAN TECH SOLUTIONS developed and deployed the official website for Dharma Legal Services, establishing a professional digital platform for the legal services organization.",
      "The website is designed to communicate the organization's professional identity, present legal services, and provide convenient channels for prospective clients to connect.",
      "This project further strengthens our portfolio in the legal and professional services sector.",
    ],
    highlights: ["Legal services digital presence", "Professional brand identity", "Organized service presentation", "Contact and enquiry-oriented website experience"],
    contribution: dd, desktop: dlD.url, mobile: dlM.url,
  },
];

export function getProject(slug: string) {
  return PROJECTS.find((p) => p.slug === slug);
}

export function filterProjects(category: Category) {
  return category === "All Projects" ? PROJECTS : PROJECTS.filter((p) => p.filters.includes(category));
}

export function relatedProjects(slug: string, count = 3) {
  const current = getProject(slug);
  if (!current) return PROJECTS.slice(0, count);
  const same = PROJECTS.filter((p) => p.slug !== slug && p.filters.some((f) => current.filters.includes(f)));
  const rest = PROJECTS.filter((p) => p.slug !== slug && !same.includes(p));
  return [...same, ...rest].slice(0, count);
}
