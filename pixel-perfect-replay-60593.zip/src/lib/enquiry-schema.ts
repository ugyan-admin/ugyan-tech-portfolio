import { z } from "zod";
import { BUDGET_OPTIONS, SERVICE_OPTIONS } from "./site";

export const enquirySchema = z.object({
  fullName: z.string().trim().min(2, "Please enter your full name").max(100),
  company: z.string().trim().max(150).optional().default(""),
  email: z.string().trim().email("Please enter a valid email address").max(255),
  mobile: z.string().trim().regex(/^\+?[0-9\s-]{10,16}$/, "Please enter a valid mobile number"),
  service: z.enum(SERVICE_OPTIONS, { errorMap: () => ({ message: "Please choose a service" }) }),
  budget: z.enum(BUDGET_OPTIONS, { errorMap: () => ({ message: "Please choose a budget range" }) }),
  description: z.string().trim().min(20, "Please describe your project in at least 20 characters").max(3000),
});
export type EnquiryInput = z.infer<typeof enquirySchema>;
