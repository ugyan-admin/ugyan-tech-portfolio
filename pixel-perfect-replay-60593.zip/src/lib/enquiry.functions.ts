import { createServerFn } from "@tanstack/react-start";
import { enquirySchema } from "./enquiry-schema";

export const submitEnquiry = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => enquirySchema.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("project_enquiries").insert({
      full_name: data.fullName,
      company: data.company || null,
      email: data.email,
      mobile: data.mobile,
      service: data.service,
      budget: data.budget,
      description: data.description,
    });
    if (error) {
      console.error("enquiry insert failed", error);
      throw new Error("We couldn't save your enquiry right now.");
    }
    return { ok: true as const };
  });
