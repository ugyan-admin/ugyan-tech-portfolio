export const CONTACT = {
  company: "UGYAN TECH SOLUTIONS",
  parent: "UGYAN EDUTECH PVT LTD",
  website: "https://tech.ugyan.in/",
  parentWebsite: "https://www.ugyan.in/",
  email: "support@ugyan.in",
  phoneDisplay: "+91 80886 51951",
  phoneE164: "918088651951",
  location: "Bengaluru, Karnataka, India",
  linkedin: "https://www.linkedin.com/company/ugyan-tech-solutions/",
  tagline: "Turning Ideas into Digital Experiences.",
};

export const WHATSAPP_MESSAGE =
  "Hello UGYAN TECH SOLUTIONS, I am interested in your website development and technology services. I would like to discuss a project requirement.";

export function whatsappLink(message: string = WHATSAPP_MESSAGE) {
  return `https://wa.me/${CONTACT.phoneE164}?text=${encodeURIComponent(message)}`;
}

export const NAV = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About Us" },
  { to: "/services", label: "Services" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/industries", label: "Industries" },
  { to: "/process", label: "Our Process" },
  { to: "/contact", label: "Contact Us" },
] as const;

export const SERVICE_OPTIONS = [
  "Website Design & Development",
  "E-Commerce Development",
  "Custom Web Application",
  "Landing Page Development",
  "Website Redesign",
  "Website Maintenance",
  "Domain & Hosting",
  "Other",
] as const;

export const BUDGET_OPTIONS = [
  "Below ₹10,000",
  "₹10,000 – ₹25,000",
  "₹25,000 – ₹50,000",
  "₹50,000 – ₹1,00,000",
  "Above ₹1,00,000",
  "Need Consultation",
] as const;
