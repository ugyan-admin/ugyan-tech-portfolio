import { Link } from "@tanstack/react-router";
import { Linkedin, Mail, Phone, Globe } from "lucide-react";
import { CONTACT } from "@/lib/site";
import { Logo } from "./Logo";

const quick = [
  { to: "/", label: "Home" }, { to: "/about", label: "About Us" }, { to: "/services", label: "Services" },
  { to: "/portfolio", label: "Portfolio" }, { to: "/industries", label: "Industries" }, { to: "/contact", label: "Contact Us" },
] as const;
const services = ["Website Development", "E-Commerce Development", "Custom Web Applications", "Website Redesign", "Website Maintenance", "Digital Solutions"];

export function SiteFooter() {
  return (
    <footer className="bg-navy-deep text-navy-muted">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-20 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo tone="light" />
          <p className="mt-5 text-sm">A Division of <a href={CONTACT.parentWebsite} target="_blank" rel="noopener noreferrer" className="hover:text-gold">{CONTACT.parent}</a>.</p>
          <p className="mt-3 font-display text-base font-semibold text-navy-foreground">“{CONTACT.tagline}”</p>
        </div>
        <div>
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-navy-foreground">Quick Links</h3>
          <ul className="mt-5 space-y-3 text-sm">{quick.map((q) => <li key={q.to}><Link to={q.to} className="hover:text-gold">{q.label}</Link></li>)}</ul>
        </div>
        <div>
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-navy-foreground">Our Services</h3>
          <ul className="mt-5 space-y-3 text-sm">{services.map((s) => <li key={s}><Link to="/services" className="hover:text-gold">{s}</Link></li>)}</ul>
        </div>
        <div>
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-navy-foreground">Connect With Us</h3>
          <ul className="mt-5 space-y-3 text-sm">
            <li><a href={`mailto:${CONTACT.email}`} className="inline-flex items-center gap-2 hover:text-gold"><Mail className="h-4 w-4 text-gold" />{CONTACT.email}</a></li>
            <li><a href={`tel:+${CONTACT.phoneE164}`} className="inline-flex items-center gap-2 hover:text-gold"><Phone className="h-4 w-4 text-gold" />{CONTACT.phoneDisplay}</a></li>
            <li><a href={CONTACT.website} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 hover:text-gold"><Globe className="h-4 w-4 text-gold" />tech.ugyan.in</a></li>
            <li><a href={CONTACT.linkedin} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 hover:text-gold"><Linkedin className="h-4 w-4 text-gold" />LinkedIn</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-navy-foreground/10">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-6 py-6 text-xs sm:flex-row sm:justify-between">
          <p>© 2026 UGYAN TECH SOLUTIONS. All Rights Reserved.</p>
          <p>A Division of UGYAN EDUTECH PVT LTD.</p>
        </div>
      </div>
    </footer>
  );
}
