import { Link } from "@tanstack/react-router";
import { ArrowUpRight, ExternalLink } from "lucide-react";
import type { Project } from "@/lib/projects";

export function ProjectCard({ project }: { project: Project }) {
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-card transition-all duration-500 hover:-translate-y-1.5 hover:shadow-lift">
      <div className="relative overflow-hidden bg-surface">
        <img src={project.desktop} alt={`${project.name} website homepage`} loading="lazy" decoding="async" className="aspect-[16/10] w-full object-cover object-top transition-transform duration-700 group-hover:scale-105" />
        <div className="absolute inset-0 flex flex-col items-start justify-end gap-3 bg-navy/85 p-6 opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-within:opacity-100">
          <p className="font-display text-2xl font-bold text-navy-foreground">{project.name}</p>
          <a href={project.url} target="_blank" rel="noopener noreferrer" className="btn btn-gold !py-2 !text-sm">
            Visit Website <ExternalLink className="h-4 w-4" />
          </a>
        </div>
        <span className="absolute left-4 top-4 rounded-full bg-background/90 px-3 py-1 font-display text-xs font-bold text-navy">{project.no}</span>
      </div>
      <div className="flex flex-1 flex-col p-6">
        <p className="eyebrow !text-[0.65rem]">{project.industry}</p>
        <h3 className="mt-2 text-xl font-bold text-navy">{project.name}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{project.short}</p>
        <div className="mt-5 flex items-center justify-between gap-3 border-t border-border pt-4">
          <Link to="/portfolio/$slug" params={{ slug: project.slug }} className="inline-flex items-center gap-1.5 text-sm font-bold text-navy transition-colors hover:text-gold">
            View Project <ArrowUpRight className="h-4 w-4" />
          </Link>
          <a href={project.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-gold" aria-label={`Visit ${project.name} live website`}>
            Live site <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </article>
  );
}
