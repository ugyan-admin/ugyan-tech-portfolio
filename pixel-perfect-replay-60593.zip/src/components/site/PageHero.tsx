import type { ReactNode } from "react";

export function PageHero({ eyebrow, title, intro, children }: { eyebrow: string; title: ReactNode; intro?: ReactNode; children?: ReactNode }) {
  return (
    <section className="relative overflow-hidden bg-navy-gradient pb-20 pt-36 sm:pt-44">
      <div className="absolute inset-0 grid-pattern" aria-hidden />
      <div className="absolute -left-40 bottom-0 h-80 w-80 rounded-full bg-gold/15 blur-3xl" aria-hidden />
      <div className="relative mx-auto max-w-7xl px-6">
        <p className="eyebrow mb-5">{eyebrow}</p>
        <h1 className="max-w-4xl text-balance text-4xl font-bold leading-[1.05] text-navy-foreground sm:text-6xl">{title}</h1>
        {intro && <p className="mt-6 max-w-2xl text-lg leading-relaxed text-navy-muted">{intro}</p>}
        {children}
      </div>
    </section>
  );
}
