import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";

export function CtaBand() {
  return (
    <section className="relative overflow-hidden bg-navy-gradient py-24">
      <div className="absolute inset-0 grid-pattern opacity-60" aria-hidden />
      <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-gold/20 blur-3xl" aria-hidden />
      <div className="relative mx-auto max-w-4xl px-6 text-center">
        <p className="eyebrow mb-5">Let's work together</p>
        <h2 className="text-balance text-3xl font-bold leading-tight text-navy-foreground sm:text-5xl">
          Your Next Digital <span className="text-gold-gradient">Success Story</span> Starts Here.
        </h2>
        <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-navy-muted">
          Whether you are launching a startup, building a business website, introducing a new product, or transforming your existing digital presence, UGYAN TECH SOLUTIONS is ready to help you move forward.
        </p>
        <div className="mt-10 flex flex-wrap justify-center gap-4">
          <Link to="/contact" className="btn btn-gold">Start Your Project <ArrowRight className="h-4 w-4" /></Link>
          <Link to="/portfolio" className="btn btn-ghost-light">Explore Our Work</Link>
        </div>
      </div>
    </section>
  );
}
