import { useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { toast } from "sonner";
import { enquirySchema } from "@/lib/enquiry-schema";
import { submitEnquiry } from "@/lib/enquiry.functions";
import { BUDGET_OPTIONS, SERVICE_OPTIONS, whatsappLink } from "@/lib/site";
import { WhatsAppIcon } from "./WhatsAppFab";

type Errors = Partial<Record<string, string>>;
const field = "w-full rounded-xl border border-input bg-background px-4 py-3 text-sm text-navy outline-none transition focus:border-gold focus:ring-2 focus:ring-gold/30 aria-[invalid=true]:border-destructive";

export function EnquiryForm() {
  const send = useServerFn(submitEnquiry);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [last, setLast] = useState<Record<string, string>>({});

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const raw = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    setLast(raw);
    const parsed = enquirySchema.safeParse(raw);
    if (!parsed.success) {
      const errs: Errors = {};
      for (const i of parsed.error.issues) errs[String(i.path[0])] ??= i.message;
      setErrors(errs);
      toast.error("Please check the highlighted fields.");
      return;
    }
    setErrors({});
    setStatus("sending");
    try {
      await send({ data: parsed.data });
      setStatus("done");
      toast.success("Thank you! Your project enquiry has been received.");
    } catch {
      setStatus("error");
      toast.error("We couldn't submit your enquiry. Please try again or reach us on WhatsApp.");
    }
  }

  const waFallback = whatsappLink(
    `Hello UGYAN TECH SOLUTIONS, I would like to discuss a project.\nName: ${last["fullName"] ?? ""}\nService: ${last["service"] ?? ""}\nBudget: ${last["budget"] ?? ""}\nDetails: ${last["description"] ?? ""}`,
  );

  if (status === "done") {
    return (
      <div className="rounded-3xl border border-border bg-card p-10 text-center shadow-card">
        <CheckCircle2 className="mx-auto h-14 w-14 text-gold" />
        <h3 className="mt-5 text-2xl font-bold text-navy">Enquiry received</h3>
        <p className="mt-3 text-muted-foreground">Thank you for reaching out. Our team will connect with you to discuss the right digital solution.</p>
        <button type="button" onClick={() => setStatus("idle")} className="btn btn-ghost mt-8">Send another enquiry</button>
      </div>
    );
  }

  const err = (k: string) => errors[k] && <p id={`${k}-err`} className="mt-1.5 text-xs font-medium text-destructive">{errors[k]}</p>;
  const a = (k: string) => ({ id: k, name: k, "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `${k}-err` : undefined });

  return (
    <form onSubmit={onSubmit} noValidate className="rounded-3xl border border-border bg-card p-6 shadow-card sm:p-10">
      <div className="grid gap-5 sm:grid-cols-2">
        <div><label htmlFor="fullName" className="mb-1.5 block text-sm font-semibold text-navy">Full Name *</label><input {...a("fullName")} autoComplete="name" className={field} maxLength={100} />{err("fullName")}</div>
        <div><label htmlFor="company" className="mb-1.5 block text-sm font-semibold text-navy">Company / Organization</label><input {...a("company")} autoComplete="organization" className={field} maxLength={150} />{err("company")}</div>
        <div><label htmlFor="email" className="mb-1.5 block text-sm font-semibold text-navy">Email Address *</label><input {...a("email")} type="email" autoComplete="email" className={field} maxLength={255} />{err("email")}</div>
        <div><label htmlFor="mobile" className="mb-1.5 block text-sm font-semibold text-navy">Mobile Number *</label><input {...a("mobile")} type="tel" autoComplete="tel" className={field} maxLength={16} placeholder="+91" />{err("mobile")}</div>
        <div><label htmlFor="service" className="mb-1.5 block text-sm font-semibold text-navy">Service Required *</label>
          <select {...a("service")} defaultValue="" className={field}><option value="" disabled>Select a service</option>{SERVICE_OPTIONS.map((s) => <option key={s}>{s}</option>)}</select>{err("service")}</div>
        <div><label htmlFor="budget" className="mb-1.5 block text-sm font-semibold text-navy">Estimated Project Budget *</label>
          <select {...a("budget")} defaultValue="" className={field}><option value="" disabled>Select a budget</option>{BUDGET_OPTIONS.map((s) => <option key={s}>{s}</option>)}</select>{err("budget")}</div>
        <div className="sm:col-span-2"><label htmlFor="description" className="mb-1.5 block text-sm font-semibold text-navy">Project Description *</label>
          <textarea {...a("description")} rows={5} className={field} maxLength={3000} placeholder="Tell us about your business and what you'd like to build." />{err("description")}</div>
      </div>
      {status === "error" && (
        <div className="mt-6 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-navy">
          Something went wrong while submitting. You can try again, or{" "}
          <a href={waFallback} target="_blank" rel="noopener noreferrer" className="font-bold text-navy underline decoration-gold underline-offset-4">send these details on WhatsApp</a>.
        </div>
      )}
      <div className="mt-8 flex flex-wrap items-center gap-4">
        <button type="submit" disabled={status === "sending"} className="btn btn-gold disabled:opacity-60">
          {status === "sending" ? <><Loader2 className="h-4 w-4 animate-spin" /> Submitting…</> : <>Submit Project Enquiry <Send className="h-4 w-4" /></>}
        </button>
        <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-navy">
          <WhatsAppIcon className="h-5 w-5 text-whatsapp" /> Prefer WhatsApp?
        </a>
      </div>
    </form>
  );
}
