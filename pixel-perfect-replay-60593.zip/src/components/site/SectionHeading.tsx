import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function SectionHeading({ eyebrow, title, intro, align = "left", tone = "dark", as: H = "h2" }: { eyebrow?: string; title: ReactNode; intro?: ReactNode; align?: "left" | "center"; tone?: "dark" | "light"; as?: "h1" | "h2" }) {
  return (
    <div className={cn("max-w-3xl", align === "center" && "mx-auto text-center")}>
      {eyebrow && <p className="eyebrow mb-4">{eyebrow}</p>}
      <H className={cn("text-balance text-3xl font-bold leading-[1.1] sm:text-4xl lg:text-5xl", tone === "light" ? "text-navy-foreground" : "text-navy")}>{title}</H>
      {intro && <p className={cn("mt-5 text-lg leading-relaxed", tone === "light" ? "text-navy-muted" : "text-muted-foreground")}>{intro}</p>}
    </div>
  );
}
