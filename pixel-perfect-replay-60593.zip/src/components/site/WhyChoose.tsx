import { Briefcase, Layers, Palette, Handshake, RefreshCcw, TrendingUp } from "lucide-react";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";

const items = [
  { i: Briefcase, t: "Business-Focused Approach", d: "We understand business objectives before developing digital solutions." },
  { i: Layers, t: "Cross-Industry Experience", d: "Our completed projects span eight organizations across different industries." },
  { i: Palette, t: "Modern Design Philosophy", d: "We prioritize modern layouts, usability, responsiveness, and professional presentation." },
  { i: Handshake, t: "Client-Centric Execution", d: "We work around client requirements, agreed project scope, and clear communication." },
  { i: RefreshCcw, t: "Complete Project Lifecycle", d: "From requirement gathering to development, testing, and deployment." },
  { i: TrendingUp, t: "Growth-Oriented Solutions", d: "We aim to develop digital foundations that businesses can improve and expand as their requirements evolve." },
];

export function WhyChoose() {
  return (
    <section className="bg-surface py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionHeading eyebrow="Why UGYAN TECH SOLUTIONS" title={<>More Than Website Development. <span className="text-gold-gradient">A Technology Partnership.</span></>} />
        <div className="mt-14 grid gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {items.map(({ i: Icon, t, d }, k) => (
            <Reveal key={t} delay={k * 70} className="group bg-card p-8 transition-colors hover:bg-navy">
              <Icon className="h-8 w-8 text-gold" />
              <h3 className="mt-6 text-lg font-bold text-navy transition-colors group-hover:text-navy-foreground">{t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground transition-colors group-hover:text-navy-muted">{d}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
