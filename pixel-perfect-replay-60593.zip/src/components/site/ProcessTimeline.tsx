import { Reveal } from "./Reveal";

export const STEPS = [
  { t: "Discover", d: "Understand the business, project requirements, target audience, and objectives." },
  { t: "Plan", d: "Define website structure, page hierarchy, content requirements, and technical approach." },
  { t: "Design", d: "Develop the visual direction, layouts, and user experience." },
  { t: "Develop", d: "Build the website and implement the agreed functionalities." },
  { t: "Test & Deploy", d: "Review, test, and deploy the approved website." },
  { t: "Support & Grow", d: "Provide agreed post-deployment assistance and future enhancements." },
];

export function ProcessTimeline() {
  return (
    <ol className="relative grid gap-10 lg:grid-cols-6 lg:gap-6">
      <span className="absolute left-6 top-0 h-full w-px bg-border lg:left-0 lg:top-6 lg:h-px lg:w-full" aria-hidden />
      {STEPS.map((s, i) => (
        <Reveal as="li" key={s.t} delay={i * 90} className="relative pl-20 lg:pl-0 lg:pt-20">
          <span className="absolute left-0 top-0 grid h-12 w-12 place-items-center rounded-full bg-navy font-display text-sm font-bold text-gold ring-8 ring-background">{String(i + 1).padStart(2, "0")}</span>
          <p className="eyebrow !text-[0.65rem]">Step {String(i + 1).padStart(2, "0")}</p>
          <h3 className="mt-1 text-lg font-bold text-navy">{s.t}</h3>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.d}</p>
        </Reveal>
      ))}
    </ol>
  );
}
