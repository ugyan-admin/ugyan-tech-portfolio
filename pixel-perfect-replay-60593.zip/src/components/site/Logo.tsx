import { Link } from "@tanstack/react-router";
import logo from "@/assets/uts-logo.png.asset.json";
import mark from "@/assets/uts-mark.png.asset.json";

export function Logo({ tone = "dark" }: { tone?: "dark" | "light" }) {
  if (tone === "light") {
    return (
      <Link to="/" className="flex items-center gap-3" aria-label="UGYAN TECH SOLUTIONS home">
        <img src={mark.url} alt="" width={44} height={44} className="h-11 w-11" />
        <span className="leading-none">
          <span className="block font-display text-xl font-extrabold tracking-tight text-navy-foreground">UGYAN</span>
          <span className="mt-1 block text-[0.62rem] font-bold tracking-[0.22em] text-gold">TECH SOLUTIONS</span>
        </span>
      </Link>
    );
  }
  return (
    <Link to="/" className="block shrink-0" aria-label="UGYAN TECH SOLUTIONS home">
      <img src={logo.url} alt="UGYAN TECH SOLUTIONS" width={490} height={160} className="h-11 w-auto sm:h-12" />
    </Link>
  );
}
