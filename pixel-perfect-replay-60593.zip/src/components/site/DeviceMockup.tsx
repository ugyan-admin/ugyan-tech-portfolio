import { cn } from "@/lib/utils";

export function BrowserFrame({ src, alt, url, className, eager }: { src: string; alt: string; url?: string; className?: string; eager?: boolean }) {
  return (
    <div className={cn("overflow-hidden rounded-xl border border-border bg-card shadow-lift", className)}>
      <div className="flex items-center gap-2 border-b border-border bg-surface px-3 py-2">
        <span className="h-2.5 w-2.5 rounded-full bg-border" />
        <span className="h-2.5 w-2.5 rounded-full bg-border" />
        <span className="h-2.5 w-2.5 rounded-full bg-border" />
        {url && <span className="ml-2 truncate rounded-md bg-background px-2 py-0.5 text-[0.65rem] text-muted-foreground">{url.replace(/^https?:\/\//, "").replace(/\/$/, "")}</span>}
      </div>
      <img src={src} alt={alt} loading={eager ? "eager" : "lazy"} decoding="async" className="block aspect-[16/10] w-full object-cover object-top" />
    </div>
  );
}

export function PhoneFrame({ src, alt, className, eager }: { src: string; alt: string; className?: string; eager?: boolean }) {
  return (
    <div className={cn("overflow-hidden rounded-[1.6rem] border-[6px] border-navy bg-navy shadow-lift", className)}>
      <img src={src} alt={alt} loading={eager ? "eager" : "lazy"} decoding="async" className="block aspect-[390/780] w-full rounded-[1.1rem] object-cover object-top" />
    </div>
  );
}
