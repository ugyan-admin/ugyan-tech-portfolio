import { createFileRoute, Link } from "@tanstack/react-router";
import { GraduationCap, Scale, HeartPulse, ShoppingCart, Factory, Sprout, UtensilsCrossed, Rocket, HandHeart, Gem, CheckCircle2 } from "lucide-react";
import { seo } from "@/lib/seo";
import { PageHero } from "@/components/site/PageHero";
import { Reveal } from "@/components/site/Reveal";
import { SectionHeading } from "@/components/site/SectionHeading";
import { CtaBand } from "@/components/site/CtaBand";

export const Route = createFileRoute("/industries")({
  head: () => ({ meta: seo("Industries We Serve — UGYAN TECH SOLUTIONS", "Technology solutions across education, legal, healthcare, retail, manufacturing, horticulture, food brands, startups, NGOs and specialty businesses.") }),
  component: Industries,
});

const INDUSTRIES = [
  { i: GraduationCap, t: "Education & EdTech", done: "student-mitra" },
  { i: Scale, t: "Legal & Professional Services", done: "gk-legal-firm" },
  { i: HeartPulse, t: "Healthcare & Wellness" },
  { i: ShoppingCart, t: "E-Commerce & Retail" },
  { i: Factory, t: "Manufacturing & Industrial Businesses" },
  { i: Sprout, t: "Agriculture & Horticulture", done: "ngg-plants" },
  { i: UtensilsCrossed, t: "Food & Consumer Brands", done: "palleturu-pachallu" },
  { i: Rocket, t: "Startups & SMEs" },
  { i: HandHeart, t: "NGOs & Social Organizations", done: "kodai-charity" },
  { i: Gem, t: "Gemstones & Specialty Businesses", done: "spektrum-gems" },
] as const;

function Industries() {
  return (
    <>
      <PageHero eyebrow="Industries" title={<>Technology Solutions <span className="text-gold-gradient">Across Industries.</span></>} intro="Our experience across multiple industries helps us understand diverse business requirements and digital communication needs." />
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex flex-wrap items-center gap-6 rounded-2xl border border-border bg-surface p-5 text-sm">
            <span className="inline-flex items-center gap-2 font-semibold text-navy"><CheckCircle2 className="h-5 w-5 text-gold" /> Completed project in this industry</span>
            <span className="inline-flex items-center gap-2 font-semibold text-muted-foreground"><span className="h-4 w-4 rounded-full border-2 border-border" /> Industry we're prepared to serve</span>
          </div>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {INDUSTRIES.map((x, k) => {
              const Icon = x.i;
              const done = "done" in x;
              return (
                <Reveal key={x.t} delay={(k % 5) * 60} className={done ? "rounded-2xl bg-navy-gradient p-6 shadow-lift" : "rounded-2xl border border-border bg-card p-6 shadow-card"}>
                  <Icon className="h-8 w-8 text-gold" />
                  <h2 className={`mt-6 font-display font-bold leading-snug ${done ? "text-navy-foreground" : "text-navy"}`}>{x.t}</h2>
                  {done ? (
                    <Link to="/portfolio/$slug" params={{ slug: x.done }} className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-gold hover:underline"><CheckCircle2 className="h-4 w-4" /> View our project</Link>
                  ) : (
                    <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Ready to serve</p>
                  )}
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>
      <section className="bg-surface py-24">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <SectionHeading align="center" eyebrow="Don't see your industry?" title="Every business has a story worth telling online." intro="We work around each client's unique identity and requirements. Tell us about yours." />
          <Link to="/contact" className="btn btn-navy mt-10">Discuss Your Project</Link>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
