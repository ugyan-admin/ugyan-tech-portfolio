import { createFileRoute } from "@tanstack/react-router";
import { Lightbulb, Award, HeartHandshake, Eye, TrendingUp, Cpu, Target, Compass } from "lucide-react";
import { seo } from "@/lib/seo";
import { PageHero } from "@/components/site/PageHero";
import { Reveal } from "@/components/site/Reveal";
import { SectionHeading } from "@/components/site/SectionHeading";
import { WhyChoose } from "@/components/site/WhyChoose";
import { CtaBand } from "@/components/site/CtaBand";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: seo("About Us — UGYAN TECH SOLUTIONS", "UGYAN TECH SOLUTIONS is a technology solutions division of UGYAN EDUTECH PVT LTD, helping businesses build a professional digital presence.") }),
  component: About,
});

const values = [
  { i: Lightbulb, t: "Innovation" }, { i: Award, t: "Quality" }, { i: HeartHandshake, t: "Client Commitment" },
  { i: Eye, t: "Transparency" }, { i: TrendingUp, t: "Continuous Improvement" }, { i: Cpu, t: "Technology Excellence" },
];

function About() {
  return (
    <>
      <PageHero eyebrow="About Us" title={<>Building Technology. <span className="text-gold-gradient">Creating Opportunities.</span></>} intro="An emerging technology solutions brand operating as a division of UGYAN EDUTECH PVT LTD." />
      <section className="py-24">
        <div className="mx-auto grid max-w-7xl gap-14 px-6 lg:grid-cols-[1fr_1.3fr]">
          <Reveal><p className="font-display text-3xl font-bold leading-snug text-navy sm:text-4xl">We believe every business deserves a <span className="text-gold-gradient">professional digital presence.</span></p></Reveal>
          <Reveal delay={100} className="space-y-5 text-lg leading-relaxed text-muted-foreground">
            <p>UGYAN TECH SOLUTIONS is an emerging technology solutions brand operating as a division of UGYAN EDUTECH PVT LTD.</p>
            <p>Our focus is to help organizations communicate their value, reach their audiences, and strengthen their operations through modern digital solutions.</p>
            <p>We work across multiple business sectors, developing websites and technology solutions that reflect each client's unique identity and requirements.</p>
            <p>Our completed projects include organizations in education, legal services, charity, horticulture, gemstones, traditional food products, and local digital services.</p>
            <p>We aim to build long-term client relationships through quality execution, transparent communication, and technology-driven problem-solving.</p>
          </Reveal>
        </div>
      </section>
      <section className="pb-24">
        <div className="mx-auto grid max-w-7xl gap-6 px-6 md:grid-cols-2">
          {[{ i: Compass, t: "Vision", d: "To become a trusted technology partner for businesses by delivering innovative, accessible, and scalable digital solutions." },
            { i: Target, t: "Mission", d: "To empower businesses through professional web development and technology solutions that transform ideas into meaningful digital experiences." }].map(({ i: Icon, t, d }, k) => (
            <Reveal key={t} delay={k * 100} className="rounded-3xl bg-navy-gradient p-10">
              <Icon className="h-9 w-9 text-gold" />
              <h2 className="mt-6 text-2xl font-bold text-navy-foreground">{t}</h2>
              <p className="mt-3 text-lg leading-relaxed text-navy-muted">{d}</p>
            </Reveal>
          ))}
        </div>
      </section>
      <section className="pb-24">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeading eyebrow="What guides us" title="Core Values" />
          <div className="mt-12 grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-6">
            {values.map(({ i: Icon, t }, k) => (
              <Reveal key={t} delay={k * 60} className="rounded-2xl border border-border bg-card p-6 text-center shadow-card transition hover:-translate-y-1 hover:border-gold">
                <Icon className="mx-auto h-8 w-8 text-gold" />
                <p className="mt-4 font-display font-bold text-navy">{t}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <WhyChoose />
      <CtaBand />
    </>
  );
}
