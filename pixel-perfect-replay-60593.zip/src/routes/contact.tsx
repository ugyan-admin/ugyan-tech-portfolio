import { createFileRoute } from "@tanstack/react-router";
import { Building2, Globe, Mail, MapPin, Phone } from "lucide-react";
import { seo } from "@/lib/seo";
import { CONTACT, whatsappLink } from "@/lib/site";
import { PageHero } from "@/components/site/PageHero";
import { EnquiryForm } from "@/components/site/EnquiryForm";
import { WhatsAppIcon } from "@/components/site/WhatsAppFab";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: seo("Contact Us — Start Your Project | UGYAN TECH SOLUTIONS", "Tell us about your business and project requirements. Email support@ugyan.in or call +91 80886 51951. Based in Bengaluru.") }),
  component: Contact,
});

function Contact() {
  const rows = [
    { i: Building2, l: "Company", v: `${CONTACT.company} — a division of ${CONTACT.parent}` },
    { i: Mail, l: "Email", v: CONTACT.email, href: `mailto:${CONTACT.email}` },
    { i: Phone, l: "Phone", v: CONTACT.phoneDisplay, href: `tel:+${CONTACT.phoneE164}` },
    { i: Globe, l: "Website", v: "tech.ugyan.in", href: CONTACT.website },
    { i: MapPin, l: "Location", v: CONTACT.location },
  ];
  return (
    <>
      <PageHero eyebrow="Contact Us" title={<>Let's Build Something <span className="text-gold-gradient">Great Together.</span></>} intro="Tell us about your business and your project requirements. Our team will connect with you to discuss the right digital solution." />
      <section className="py-20">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 lg:grid-cols-[1fr_1.6fr]">
          <aside className="space-y-4">
            {rows.map(({ i: Icon, l, v, href }) => (
              <div key={l} className="flex items-start gap-4 rounded-2xl border border-border bg-card p-5 shadow-card">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-navy text-gold"><Icon className="h-5 w-5" /></span>
                <div className="min-w-0">
                  <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{l}</p>
                  {href ? <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer" className="mt-1 block break-words font-semibold text-navy hover:text-gold">{v}</a> : <p className="mt-1 font-semibold text-navy">{v}</p>}
                </div>
              </div>
            ))}
            <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 rounded-2xl bg-navy-gradient p-5 transition hover:-translate-y-0.5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-whatsapp text-navy-foreground"><WhatsAppIcon className="h-6 w-6" /></span>
              <span><span className="block font-display font-bold text-navy-foreground">Chat on WhatsApp</span><span className="text-sm text-navy-muted">Quick replies to your project questions</span></span>
            </a>
          </aside>
          <EnquiryForm />
        </div>
      </section>
    </>
  );
}
