import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Check, ExternalLink } from "lucide-react";
import { getProject, relatedProjects } from "@/lib/projects";
import { seo } from "@/lib/seo";
import { BrowserFrame, PhoneFrame } from "@/components/site/DeviceMockup";
import { ProjectCard } from "@/components/site/ProjectCard";
import { Reveal } from "@/components/site/Reveal";
import { CtaBand } from "@/components/site/CtaBand";

export const Route = createFileRoute("/portfolio/$slug")({
  loader: ({ params }) => {
    const project = getProject(params.slug);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? seo(`${loaderData.project.name} — ${loaderData.project.category} | UGYAN TECH SOLUTIONS`, `${loaderData.project.short} A ${loaderData.project.industry.toLowerCase()} project by UGYAN TECH SOLUTIONS.`)
      : [{ title: "Project not found — UGYAN TECH SOLUTIONS" }, { name: "robots", content: "noindex" }],
  }),
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-6 py-40 text-center">
      <h1 className="text-3xl font-bold text-navy">Project not found</h1>
      <Link to="/portfolio" className="btn btn-navy mt-8">Back to Portfolio</Link>
    </div>
  ),
  component: ProjectPage,
});

function ProjectPage() {
  const { project: p } = Route.useLoaderData();
  return (
    <>
      <section className="relative overflow-hidden bg-navy-gradient pb-16 pt-32 sm:pt-40">
        <div className="absolute inset-0 grid-pattern" aria-hidden />
        <div className="relative mx-auto max-w-7xl px-6">
          <Link to="/portfolio" className="inline-flex items-center gap-2 text-sm font-semibold text-navy-muted hover:text-gold"><ArrowLeft className="h-4 w-4" /> All projects</Link>
          <div className="mt-8 grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-end">
            <div>
              <p className="eyebrow">Project {p.no} · {p.industry}</p>
              <h1 className="mt-4 text-4xl font-bold leading-tight text-navy-foreground sm:text-6xl">{p.name}</h1>
              <p className="mt-5 max-w-xl text-lg text-navy-muted">{p.category}</p>
            </div>
            <div className="flex flex-wrap gap-4 lg:justify-end">
              <a href={p.url} target="_blank" rel="noopener noreferrer" className="btn btn-gold">Visit Live Website <ExternalLink className="h-4 w-4" /></a>
              <Link to="/contact" className="btn btn-ghost-light">Start a Similar Project</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-surface py-16">
        <div className="mx-auto max-w-7xl px-6">
          <div className="relative">
            <BrowserFrame src={p.desktop} alt={`${p.name} website on desktop`} url={p.url} eager />
            <PhoneFrame src={p.mobile} alt={`${p.name} website on mobile`} className="absolute -bottom-10 right-4 w-[24%] max-w-[220px] sm:right-10" />
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-[1.4fr_1fr]">
          <Reveal>
            <h2 className="text-2xl font-bold text-navy sm:text-3xl">Project Overview</h2>
            <div className="mt-5 space-y-4 text-lg leading-relaxed text-muted-foreground">{p.description.map((d) => <p key={d}>{d}</p>)}</div>
            <h2 className="mt-14 text-2xl font-bold text-navy sm:text-3xl">Project Objectives</h2>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {p.highlights.map((h) => <li key={h} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 font-medium text-navy"><Check className="mt-0.5 h-5 w-5 shrink-0 text-gold" />{h}</li>)}
            </ul>
          </Reveal>
          <Reveal delay={120} className="h-fit rounded-3xl bg-navy-gradient p-8 lg:sticky lg:top-28">
            <dl className="space-y-5 text-sm">
              <div><dt className="text-navy-muted">Client</dt><dd className="mt-1 font-display text-lg font-bold text-navy-foreground">{p.name}</dd></div>
              <div><dt className="text-navy-muted">Industry</dt><dd className="mt-1 font-semibold text-navy-foreground">{p.industry}</dd></div>
              <div><dt className="text-navy-muted">Category</dt><dd className="mt-1 font-semibold text-navy-foreground">{p.category}</dd></div>
              <div><dt className="text-navy-muted">Live website</dt><dd className="mt-1"><a href={p.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-gold hover:underline">{p.url.replace(/^https?:\/\//, "").replace(/\/$/, "")}</a></dd></div>
            </dl>
            <h3 className="mt-8 border-t border-navy-foreground/10 pt-6 font-display font-bold text-navy-foreground">Our Contribution</h3>
            <ul className="mt-4 space-y-2.5">{p.contribution.map((c) => <li key={c} className="flex items-center gap-2.5 text-sm text-navy-muted"><span className="h-1.5 w-1.5 rounded-full bg-gold" />{c}</li>)}</ul>
          </Reveal>
        </div>
      </section>

      <section className="bg-surface py-24">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="text-3xl font-bold text-navy">Related Projects</h2>
          <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">{relatedProjects(p.slug).map((r) => <ProjectCard key={r.slug} project={r} />)}</div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
