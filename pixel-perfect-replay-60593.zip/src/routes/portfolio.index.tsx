import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { seo } from "@/lib/seo";
import { CATEGORIES, filterProjects, type Category } from "@/lib/projects";
import { PageHero } from "@/components/site/PageHero";
import { ProjectCard } from "@/components/site/ProjectCard";
import { CtaBand } from "@/components/site/CtaBand";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/portfolio/")({
  head: () => ({ meta: seo("Portfolio — 8 Delivered Websites | UGYAN TECH SOLUTIONS", "Explore websites we've designed, developed and deployed for clients in legal, education, charity, horticulture, gemstones, food and local services.") }),
  component: Portfolio,
});

function Portfolio() {
  const [cat, setCat] = useState<Category>("All Projects");
  const list = filterProjects(cat);
  return (
    <>
      <PageHero eyebrow="Our Portfolio" title={<>Work that's <span className="text-gold-gradient">live and serving</span> real businesses.</>} intro="Eight websites successfully designed, developed and deployed across seven industry categories. Every project below is live — visit them yourself." />
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div role="tablist" aria-label="Filter projects by category" className="-mx-6 flex gap-2 overflow-x-auto px-6 pb-2 sm:flex-wrap">
            {CATEGORIES.map((c) => (
              <button key={c} role="tab" aria-selected={cat === c} onClick={() => setCat(c)}
                className={cn("shrink-0 rounded-full border px-5 py-2.5 text-sm font-semibold transition-all", cat === c ? "border-navy bg-navy text-navy-foreground" : "border-border bg-card text-navy hover:border-gold")}>
                {c}
              </button>
            ))}
          </div>
          <p className="mt-6 text-sm text-muted-foreground">{list.length} project{list.length === 1 ? "" : "s"}</p>
          <div key={cat} className="mt-6 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((p, i) => (
              <div key={p.slug} className="animate-in fade-in slide-in-from-bottom-4 fill-mode-both duration-500" style={{ animationDelay: `${i * 70}ms` }}>
                <ProjectCard project={p} />
              </div>
            ))}
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
