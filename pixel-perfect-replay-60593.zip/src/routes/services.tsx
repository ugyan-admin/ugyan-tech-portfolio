import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { seo } from "@/lib/seo";
import { SERVICES } from "@/lib/services";
import { PageHero } from "@/components/site/PageHero";
import { Reveal } from "@/components/site/Reveal";
import { CtaBand } from "@/components/site/CtaBand";

export const Route = createFileRoute("/services")({
  head: () => ({ meta: seo("Services — Web Design, E-Commerce & Web Apps | UGYAN TECH SOLUTIONS", "Website design & development, e-commerce, custom web applications, landing pages, redesigns, hosting, maintenance and digital transformation.") }),
  component: Services,
});

function Services() {
  return (
    <>
      <PageHero eyebrow="Services" title={<>Everything you need to <span className="text-gold-gradient">launch and grow</span> online.</>} intro="From your first website to custom business applications, we design, develop, deploy and support digital solutions shaped around your requirements." />
      <section className="py-24">
        <div className="mx-auto grid max-w-7xl gap-6 px-6 md:grid-cols-2">
          {SERVICES.map(({ no, title, icon: Icon, summary, items }, i) => (
            <Reveal key={no} delay={(i % 2) * 90} as="article" className="group flex flex-col rounded-3xl border border-border bg-card p-8 shadow-card transition-all hover:-translate-y-1 hover:shadow-lift sm:p-10">
              <div className="flex items-start justify-between">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-navy text-gold transition-transform group-hover:scale-110"><Icon className="h-7 w-7" /></span>
                <span className="font-display text-4xl font-bold text-border">{no}</span>
              </div>
              <h2 className="mt-8 text-2xl font-bold text-navy">{title}</h2>
              <p className="mt-3 leading-relaxed text-muted-foreground">{summary}</p>
              <ul className="mt-6 grid flex-1 gap-2.5 sm:grid-cols-2">
                {items.map((it) => <li key={it} className="flex items-start gap-2 text-sm font-medium text-navy"><Check className="mt-0.5 h-4 w-4 shrink-0 text-gold" />{it}</li>)}
              </ul>
              <Link to="/contact" className="mt-8 inline-flex items-center gap-2 self-start font-bold text-navy transition-colors hover:text-gold">Discuss Your Project <ArrowRight className="h-4 w-4" /></Link>
            </Reveal>
          ))}
        </div>
      </section>
      <CtaBand />
    </>
  );
}
