import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Sparkles } from "lucide-react";
import { seo } from "@/lib/seo";
import { PROJECTS } from "@/lib/projects";
import { SERVICES } from "@/lib/services";
import { BrowserFrame, PhoneFrame } from "@/components/site/DeviceMockup";
import { Counter } from "@/components/site/Counter";
import { Reveal } from "@/components/site/Reveal";
import { SectionHeading } from "@/components/site/SectionHeading";
import { ProjectCard } from "@/components/site/ProjectCard";
import { ProcessTimeline } from "@/components/site/ProcessTimeline";
import { WhyChoose } from "@/components/site/WhyChoose";
import { CtaBand } from "@/components/site/CtaBand";

export const Route = createFileRoute("/")({
  head: () => ({ meta: seo("UGYAN TECH SOLUTIONS — Website Design & Development, Bengaluru", "We help businesses establish, strengthen and scale their digital presence through modern website development and technology solutions. See our 8 delivered projects.") }),
  component: Home,
});

function Home() {
  const a = PROJECTS[2]!, b = PROJECTS[6]!, c = PROJECTS[4]!;
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-navy-gradient pt-32 lg:pt-36">
        <div className="absolute inset-0 grid-pattern" aria-hidden />
        <div className="absolute right-0 top-20 h-[30rem] w-[30rem] rounded-full bg-gold/15 blur-3xl" aria-hidden />
        <div className="relative mx-auto grid max-w-7xl items-center gap-16 px-6 pb-24 lg:grid-cols-[1.05fr_1fr] lg:pb-32">
          <div className="animate-in fade-in slide-in-from-bottom-6 duration-700">
            <p className="inline-flex items-center gap-2 rounded-full border border-navy-foreground/15 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em] text-gold">
              <Sparkles className="h-3.5 w-3.5" /> Design. Develop. Deploy. Grow.
            </p>
            <h1 className="mt-7 text-balance text-4xl font-bold leading-[1.04] text-navy-foreground sm:text-6xl xl:text-[4.2rem]">
              Transforming Business Ideas into <span className="text-gold-gradient">Digital Experiences.</span>
            </h1>
            <p className="mt-7 max-w-xl text-lg leading-relaxed text-navy-muted">
              At UGYAN TECH SOLUTIONS, we help businesses establish, strengthen, and scale their digital presence through modern website development, innovative technology solutions, and business-focused digital experiences.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link to="/contact" className="btn btn-gold">Start Your Project <ArrowRight className="h-4 w-4" /></Link>
              <Link to="/portfolio" className="btn btn-ghost-light">Explore Our Portfolio</Link>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-xl lg:max-w-none" aria-hidden>
            <BrowserFrame src={a.desktop} alt="" url={a.url} eager className="animate-float relative z-10" />
            <BrowserFrame src={b.desktop} alt="" url={b.url} eager className="absolute -left-6 -bottom-16 hidden w-[62%] animate-float-delayed sm:block" />
            <PhoneFrame src={c.mobile} alt="" eager className="absolute -right-3 -bottom-20 z-20 w-[26%] animate-float-delayed" />
            <div className="absolute -top-6 right-10 z-20 rounded-2xl bg-background px-4 py-3 shadow-lift">
              <p className="font-display text-2xl font-bold text-navy">08+</p>
              <p className="text-[0.65rem] font-bold uppercase tracking-widest text-muted-foreground">Live websites</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeading eyebrow="Our track record" title="Digital Solutions Built Around Real Business Needs." />
          <div className="mt-14 grid gap-6 sm:grid-cols-3">
            {[
              { n: 8, pad: 2, s: "+", l: "Successfully Delivered Website Projects" },
              { n: 7, pad: 2, s: "+", l: "Industry Categories Served" },
              { n: 100, pad: 0, s: "%", l: "Focused on Client Requirements" },
            ].map((x, i) => (
              <Reveal key={x.l} delay={i * 100} className="rounded-3xl border border-border bg-card p-8 shadow-card">
                <p className="font-display text-6xl font-bold text-navy"><Counter to={x.n} pad={x.pad} suffix={x.s} /></p>
                <div className="my-5 h-1 w-12 rounded-full bg-gold-gradient" />
                <p className="font-semibold text-muted-foreground">{x.l}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="bg-surface py-24">
        <div className="mx-auto grid max-w-7xl gap-14 px-6 lg:grid-cols-2 lg:items-center">
          <Reveal>
            <SectionHeading eyebrow="Who we are" title="Your Technology Partner for the Digital World." />
            <Link to="/services" className="btn btn-navy mt-10">Discover Our Capabilities <ArrowRight className="h-4 w-4" /></Link>
          </Reveal>
          <Reveal delay={120} className="space-y-5 text-lg leading-relaxed text-muted-foreground">
            <p>UGYAN TECH SOLUTIONS is a technology solutions division of UGYAN EDUTECH PVT LTD, focused on delivering professional website development and digital solutions to businesses across different industries.</p>
            <p>From startups and professional service firms to educational organizations and product-based businesses, we transform business requirements into functional, modern, and engaging digital experiences.</p>
            <p>Our approach combines creativity, technology, and business understanding to develop solutions that support our clients' digital objectives.</p>
          </Reveal>
        </div>
      </section>

      {/* Portfolio */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHeading eyebrow="Selected work" title={<>Eight websites. <span className="text-gold-gradient">Seven industries.</span> All live.</>} />
            <Link to="/portfolio" className="btn btn-ghost">View Full Portfolio <ArrowUpRight className="h-4 w-4" /></Link>
          </div>
          <div className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {PROJECTS.slice(0, 6).map((p, i) => <Reveal key={p.slug} delay={(i % 3) * 90}><ProjectCard project={p} /></Reveal>)}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="bg-navy-gradient relative overflow-hidden py-24">
        <div className="absolute inset-0 grid-pattern" aria-hidden />
        <div className="relative mx-auto max-w-7xl px-6">
          <SectionHeading tone="light" eyebrow="What we do" title="Services built to move your business forward." />
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {SERVICES.map(({ no, title, icon: Icon, summary }, i) => (
              <Reveal key={no} delay={(i % 4) * 70}>
                <Link to="/services" className="group block h-full rounded-2xl border border-navy-foreground/10 bg-navy-foreground/[0.03] p-6 transition-all hover:-translate-y-1 hover:border-gold/60">
                  <div className="flex items-center justify-between"><Icon className="h-7 w-7 text-gold" /><span className="font-display text-sm font-bold text-navy-muted">{no}</span></div>
                  <h3 className="mt-6 font-bold text-navy-foreground">{title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-navy-muted">{summary}</p>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <WhyChoose />

      {/* Process */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <SectionHeading eyebrow="Our process" title="From idea to live website, in six clear steps." />
          <div className="mt-16"><ProcessTimeline /></div>
          <div className="mt-16 text-center"><Link to="/contact" className="btn btn-navy">Have a Project in Mind? Let's Discuss. <ArrowRight className="h-4 w-4" /></Link></div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
