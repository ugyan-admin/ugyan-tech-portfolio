import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { seo } from "@/lib/seo";
import { PageHero } from "@/components/site/PageHero";
import { ProcessTimeline } from "@/components/site/ProcessTimeline";
import { WhyChoose } from "@/components/site/WhyChoose";
import { CtaBand } from "@/components/site/CtaBand";

export const Route = createFileRoute("/process")({
  head: () => ({ meta: seo("Our Development Process — UGYAN TECH SOLUTIONS", "Discover, plan, design, develop, test & deploy, support & grow — how UGYAN TECH SOLUTIONS delivers your website.") }),
  component: Process,
});

function Process() {
  return (
    <>
      <PageHero eyebrow="Our Process" title={<>A clear path from <span className="text-gold-gradient">idea to launch.</span></>} intro="Six well-defined steps keep every project transparent, on scope and focused on your business objectives." />
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <ProcessTimeline />
          <div className="mt-20 text-center"><Link to="/contact" className="btn btn-gold">Have a Project in Mind? Let's Discuss. <ArrowRight className="h-4 w-4" /></Link></div>
        </div>
      </section>
      <WhyChoose />
      <CtaBand />
    </>
  );
}
